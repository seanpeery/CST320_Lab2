#pragma once

bool FindPROG();
bool FindSTMTS();
bool FindSTMT();
bool FindEXPR();
bool FindEXPR_P();
bool FindPLUSOP();
bool FindTERM();
bool FindTERM_P();
bool FindTIMESOP();
